// Appended only to a local test copy, inside the application's closure.
const testButton=document.createElement('button');testButton.id='integration-run';testButton.textContent='Testar gesto mobile';
testButton.style.cssText='position:fixed;right:5px;top:5px;z-index:999999;padding:10px;background:white;color:black';document.body.append(testButton);
const testReport=document.createElement('pre');testReport.id='integration-result';testReport.textContent='Teste local pronto';
testReport.style.cssText='position:fixed;left:5px;bottom:5px;max-height:160px;max-width:90vw;overflow:auto;z-index:999999;background:white;color:black;font:12px monospace';document.body.append(testReport);
const pause=ms=>new Promise(r=>setTimeout(r,ms));
async function waitForTest(fn){for(let i=0;i<200;i++){if(fn())return;await pause(25);}throw new Error('Timed out waiting for app rendering');}
function testPoint(s){const r=bookEl.querySelector('canvas').getBoundingClientRect();return{x:r.left+s.point[0]/600*r.width,y:r.top+(800-s.point[1])/800*r.height};}
async function holdAt(point){
 const opt={bubbles:true,pointerId:501,pointerType:'touch',isPrimary:true,button:0,buttons:1,clientX:point.x,clientY:point.y};
 const target=document.elementFromPoint(point.x,point.y)||stage;
 target.dispatchEvent(new PointerEvent('pointerdown',opt));await pause(330);
 stage.dispatchEvent(new PointerEvent('pointerup',{...opt,buttons:0}));await pause(20);
 return {point,target:target.outerHTML.slice(0,250),mapped:window.__astraAlvo?.(point.x,point.y)?.textContent};
}
testButton.onclick=async()=>{
 const out={passed:0,failed:[],checks:[]};testReport.textContent='Executando importação e gestos…';
 try{
  nativeImm=()=>{};window.__semTutorial=true;
  S.pid='selection-regression';S.profile={id:S.pid,name:'Teste local',color:'#6ef3d6'};S.set={...DEF_SET};
  LS.set('astra.tour.ler.'+S.pid,true);LS.set('astra.hint',true);
  const baseTeste=location.pathname.endsWith('/index-teste.html')?'../testes/':'../';
  const blob=await(await fetch(baseTeste+'selection-fixture.pdf')).blob();
  const b=await importOne(new File([blob],'selection-fixture.pdf',{type:'application/pdf'}));
  await openReader(b);await waitForTest(()=>!document.querySelector('.intro')&&bookEl.querySelector('.textLayer'));
  const samples=await(await fetch(baseTeste+'selection-expected.json')).json();
  for(const page of [1,2]){
   goTo(page-1);await waitForTest(()=>bookEl.querySelector('.pg')?.dataset.i===String(page-1)&&bookEl.querySelector('.textLayer')&&bookEl.querySelector('canvas'));
   for(const s of samples.filter(s=>s.page===page&&s.fraction===.5)){
    // Independent word cases start without the previous floating toolbar.
    // In vertical text that toolbar can legitimately cover the next word.
    clearSel();
    const diagnostic=await holdAt(testPoint(s));
    const expected=s.text.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu,'');
    const actual=(SEL.word||'').replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu,'');
    if(actual===expected)out.passed++;else out.failed.push({expected,actual,selection:SEL.text,mode:G&&G.mode,diagnostic});
   }
  }
  goTo(0);await waitForTest(()=>bookEl.querySelector('.pg')?.dataset.i==='0');
  const target=samples.find(s=>s.page===1&&s.text==='desconcertado.'&&s.fraction===.5);
  await holdAt(testPoint(target));
  const dict=document.querySelector('#selbar [data-s="ai"]');
  if(!dict)throw new Error('Dictionary action not shown');
  dict.click();await waitForTest(()=>document.querySelector('.sheet')?.textContent.toLowerCase().includes('desconcertado'));
  out.checks.push({name:'Dictionary receives selected word',passed:!!document.querySelector('.sheet')?.textContent.toLowerCase().includes('desconcertado')});
  /* A folha fecha visualmente em 300 ms; antes disso o scrim ainda cobre o PDF
     e engole o próximo gesto do teste. */
  while(STACK.length)STACK[STACK.length-1]();await pause(420);
  await holdAt(testPoint(target));const r=bookEl.querySelector('canvas').getBoundingClientRect();
  await holdAt({x:r.right-8,y:r.top+r.height*.7});
  out.checks.push({name:'Blank long press clears old selection',passed:!SEL.range&&!document.querySelector('#selbar')});
  await holdAt(testPoint(target));const first=samples.find(s=>s.page===1&&s.text==='Ele'&&s.fraction===.5);
  const p=testPoint(first);const hc=hitAt(p.x,p.y),hw=hc&&wordNear(hc);let cmp=null;
  try{const tr=document.createRange();tr.setStart(SEL.anchor.n,SEL.anchor.s);cmp=tr.comparePoint(hw.n,hw.s)}catch(e){cmp='erro '+e.message}
  extendSelTo(p.x,p.y);const dbg={hit:hw&&hw.n.data,cmp,range:SEL.range&&SEL.range.toString(),collapsed:SEL.range&&SEL.range.collapsed,start:SEL.range&&SEL.range.startContainer.data,end:SEL.range&&SEL.range.endContainer.data};afterSelect();
  out.checks.push({name:'Dictionary target follows extended selection',passed:SEL.word==='Ele',actual:SEL.word,dbg});
  clearSel();
  await holdAt(testPoint(first));
  const last=samples.find(s=>s.page===1&&s.text==='tablet'&&s.fraction===.5);
  const lp=testPoint(last);extendSelTo(lp.x,lp.y);afterSelect(true);
  const multi=(SEL.text||'').replace(/\s+/g,' ').trim();
  const hi=addHL('sun');
  out.checks.push({name:'Multi-line PDF selection follows visual reading order',
    passed:multi.startsWith('Ele ficou desconcertado.')&&multi.includes('Seleção ação coração informação sinônimos')&&multi.endsWith('Um livro para celular e tablet')&&hi&&hi.rects.length>=7&&hi.rects.length<=10,
    actual:multi,rects:hi&&hi.rects.length});
  clearSel();
  /* Faz o gesto completo, inclusive passando por espaços entre linhas, como o
     dedo no tablet. Nenhum espaço intermediário pode interromper a seleção. */
  const ini=testPoint(first),fim=testPoint(last),pid=777;
  stage.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,pointerId:pid,pointerType:'touch',isPrimary:true,button:0,buttons:1,clientX:ini.x,clientY:ini.y}));
  await pause(340);
  for(let n=1;n<=28;n++){const k=n/28,x=ini.x+(fim.x-ini.x)*k,y=ini.y+(fim.y-ini.y)*k;stage.dispatchEvent(new PointerEvent('pointermove',{bubbles:true,pointerId:pid,pointerType:'touch',isPrimary:true,button:0,buttons:1,clientX:x,clientY:y}));await pause(4)}
  stage.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,pointerId:pid,pointerType:'touch',isPrimary:true,button:0,buttons:0,clientX:fim.x,clientY:fim.y}));await pause(40);
  const arrastada=(SEL.text||SEL.range?.toString()||'').replace(/\s+/g,' ').trim();
  out.checks.push({name:'Long press drag keeps a continuous multi-line range',passed:arrastada.startsWith('Ele ficou desconcertado.')&&arrastada.endsWith('Um livro para celular e tablet'),actual:arrastada});
  clearSel();
  const dk=dayKey(),antes=(getStats().pages[dk]||0);R.b.readPages={};R.pageT0=Date.now()-181000;const contou=onPageLeave();
  const uma=(getStats().pages[dk]||0);R.pageT0=Date.now()-181000;const repetiu=onPageLeave();const duas=(getStats().pages[dk]||0);
  out.checks.push({name:'Page counts after three minutes only once',passed:contou===true&&repetiu===false&&uma===antes+1&&duas===uma,antes,uma,duas});
  testReport.textContent=JSON.stringify(out,null,2);document.title=out.failed.length||out.checks.some(x=>!x.passed)?'FALHA integração':'PASSOU integração';
 }catch(e){testReport.textContent=JSON.stringify({error:e.stack,out},null,2);document.title='ERRO integração';}
};

window.__astraTestZoom=async()=>{
 const r=stage.getBoundingClientRect();zoomAt(4,r.left+r.width/2,r.top+r.height/2,false);await pause(800);
 const canvas=bookEl.querySelector('canvas');
 return{lowPower:lowPowerDevice(),pixels:canvas?canvas.width*canvas.height:0,rz:R.rz,zoom:R.z};
};
window.__astraTestFeatures=async()=>{
 LS.set(vocKey(),[
  {w:'órbita',simple:'Trajetória de um corpo ao redor de outro.',ctx:'O planeta seguiu sua órbita.'},
  {w:'constelação',simple:'Conjunto aparente de estrelas no céu.',ctx:'A constelação brilhava.'},
  {w:'galáxia',simple:'Enorme conjunto de estrelas, gás e poeira.',ctx:'A galáxia parecia distante.'},
  {w:'cometa',simple:'Corpo celeste que pode formar uma cauda luminosa.',ctx:'O cometa cruzou o céu.'}
 ]);
 QUIZ.abrir();
 const qs=document.querySelector('.quiz-sheet'),quizBefore=!!qs?.querySelector('.qscene .astro')&&!!qs?.querySelector('.qprogress');
 const quizFull=!!qs&&qs.getBoundingClientRect().height>=innerHeight*.95;
 document.querySelector('.quiz-sheet .qop')?.click();await pause(80);
 const quizReaction=!!document.querySelector('.quiz-sheet .qresp .qreact .astro')&&!!document.querySelector('#qz.q-good,#qz.q-bad');
 const nr=document.querySelector('#qzNext')?.getBoundingClientRect();
 const quizNextSafe=!!nr&&nr.top>=0&&nr.bottom<=innerHeight-(innerWidth<=620?54:8);
 while(STACK.length)STACK[STACK.length-1]();await pause(360);
 const old=S.set.sounds!==false;openSettings();const soundButton=document.querySelector('#sSound'),awakeButton=document.querySelector('#sAwake'),testSound=document.querySelector('#sTestSound');soundButton?.click();
 const toggled=!!soundButton&&(S.set.sounds!==false)!==old;soundButton?.click();while(STACK.length)STACK[STACK.length-1]();
 show('lib');renderLib();await pause(40);
 const grid=document.querySelector('#grid'),drop=document.querySelector('#grid>.drop'),dr=drop?.getBoundingClientRect(),gr=grid?.getBoundingClientRect();
 const shelfFit=!!(dr&&gr&&dr.left>=gr.left-1&&dr.right<=gr.right+1&&dr.width>=120&&document.documentElement.scrollWidth<=innerWidth+1);
 meMenu();await pause(40);const profileSheet=[...document.querySelectorAll('.sheet')].pop(),handle=profileSheet?.querySelector('.grab');let sheetDismiss=false;
 if(profileSheet&&handle){const hr=handle.getBoundingClientRect(),x=hr.left+hr.width/2,y=hr.top+10,pid=991;
  handle.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true,pointerId:pid,pointerType:'touch',isPrimary:true,button:0,buttons:1,clientX:x,clientY:y}));
  profileSheet.dispatchEvent(new PointerEvent('pointermove',{bubbles:true,cancelable:true,pointerId:pid,pointerType:'touch',isPrimary:true,button:0,buttons:1,clientX:x,clientY:y+130}));
  profileSheet.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,cancelable:true,pointerId:pid,pointerType:'touch',isPrimary:true,button:0,buttons:0,clientX:x,clientY:y+130}));
  await pause(380);sheetDismiss=!profileSheet.isConnected;
 }
 CLOUD.renderLogin('in');
 const googleDisabled=!document.querySelector('#lgGoogle'),localTest=!!document.querySelector('#lgLocal');
 return{quizBefore,quizFull,quizReaction,quizNextSafe,soundButton:!!soundButton,testSound:!!testSound,awakeButton:!!awakeButton,toggled,restored:(S.set.sounds!==false)===old,keepAwake:S.set.keepAwake!==false,limit:PRO.LIM.words,googleDisabled,localTest,adsRemoved:typeof ADS==='undefined',sheetDismiss,shelfFit};
};
