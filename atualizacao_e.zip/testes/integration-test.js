// Appended only to a local test copy, inside the application's closure.
const testButton=document.createElement('button');testButton.id='integration-run';testButton.textContent='Testar gesto mobile';
testButton.style.cssText='position:fixed;right:5px;top:5px;z-index:999999;padding:10px;background:white;color:black';document.body.append(testButton);
const testReport=document.createElement('pre');testReport.id='integration-result';testReport.textContent='Teste local pronto';
testReport.style.cssText='position:fixed;left:5px;bottom:5px;max-height:160px;max-width:90vw;overflow:auto;z-index:999999;background:white;color:black;font:12px monospace';document.body.append(testReport);
const pause=ms=>new Promise(r=>setTimeout(r,ms));
async function waitForTest(fn){for(let i=0;i<200;i++){if(fn())return;await pause(25);}throw new Error('Timed out waiting for app rendering');}
function testPoint(s){const r=bookEl.querySelector('canvas').getBoundingClientRect();return{x:r.left+s.point[0]/600*r.width,y:r.top+(800-s.point[1])/800*r.height};}
async function holdAt(point){
 const opt={bubbles:true,pointerId:501,pointerType:'touch',isPrimary:true,button:0,buttons:1,clientX:point.x,clientY:point.y};
 const target=document.elementFromPoint(point.x,point.y)||stage;
 target.dispatchEvent(new PointerEvent('pointerdown',opt));await pause(330);
 stage.dispatchEvent(new PointerEvent('pointerup',{...opt,buttons:0}));await pause(20);
 return {point,target:target.outerHTML.slice(0,250),mapped:window.__astraAlvo?.(point.x,point.y)?.textContent};
}
testButton.onclick=async()=>{
 const out={passed:0,failed:[],checks:[]};testReport.textContent='Executando importação e gestos…';
 try{
  nativeImm=()=>{};window.__semTutorial=true;
  S.pid='selection-regression';S.profile={id:S.pid,name:'Teste local',color:'#6ef3d6'};S.set={...DEF_SET};
  LS.set('astra.tour.ler.'+S.pid,true);LS.set('astra.hint',true);
  const blob=await(await fetch('../testes/selection-fixture.pdf')).blob();
  const b=await importOne(new File([blob],'selection-fixture.pdf',{type:'application/pdf'}));
  await openReader(b);await waitForTest(()=>!document.querySelector('.intro')&&bookEl.querySelector('.textLayer'));
  const samples=await(await fetch('../testes/selection-expected.json')).json();
  for(const page of [1,2]){
   goTo(page-1);await waitForTest(()=>bookEl.querySelector('.pg')?.dataset.i===String(page-1)&&bookEl.querySelector('.textLayer')&&bookEl.querySelector('canvas'));
   for(const s of samples.filter(s=>s.page===page&&s.fraction===.5)){
    // Independent word cases start without the previous floating toolbar.
    // In vertical text that toolbar can legitimately cover the next word.
    clearSel();
    const diagnostic=await holdAt(testPoint(s));
    const expected=s.text.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu,'');
    const actual=(SEL.word||'').replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu,'');
    if(actual===expected)out.passed++;else out.failed.push({expected,actual,selection:SEL.text,mode:G&&G.mode,diagnostic});
   }
  }
  goTo(0);await waitForTest(()=>bookEl.querySelector('.pg')?.dataset.i==='0');
  const target=samples.find(s=>s.page===1&&s.text==='desconcertado.'&&s.fraction===.5);
  await holdAt(testPoint(target));
  const dict=document.querySelector('#selbar [data-s="ai"]');
  if(!dict)throw new Error('Dictionary action not shown');
  dict.click();await waitForTest(()=>document.querySelector('.sheet')?.textContent.toLowerCase().includes('desconcertado'));
  out.checks.push({name:'Dictionary receives selected word',passed:!!document.querySelector('.sheet')?.textContent.toLowerCase().includes('desconcertado')});
  while(STACK.length)STACK[STACK.length-1]();await pause(100);
  await holdAt(testPoint(target));const r=bookEl.querySelector('canvas').getBoundingClientRect();
  await holdAt({x:r.right-8,y:r.top+r.height*.7});
  out.checks.push({name:'Blank long press clears old selection',passed:!SEL.range&&!document.querySelector('#selbar')});
  await holdAt(testPoint(target));const first=samples.find(s=>s.page===1&&s.text==='Ele'&&s.fraction===.5);
  const p=testPoint(first);extendSelTo(p.x,p.y);afterSelect();
  out.checks.push({name:'Dictionary target follows extended selection',passed:SEL.word==='Ele',actual:SEL.word});
  clearSel();
  testReport.textContent=JSON.stringify(out,null,2);document.title=out.failed.length||out.checks.some(x=>!x.passed)?'FALHA integração':'PASSOU integração';
 }catch(e){testReport.textContent=JSON.stringify({error:e.stack,out},null,2);document.title='ERRO integração';}
};
