/* Configuração do Firebase do Astra Book (projeto astra-book). */
window.ASTRA_FIREBASE = {
  apiKey: "AIzaSyBtjAFcqZq6y3hSoSwJ-I99x8WPt5Ztfgc",
  authDomain: "astra-book.firebaseapp.com",
  projectId: "astra-book",
  storageBucket: "astra-book.firebasestorage.app",
  messagingSenderId: "264366520949",
  appId: "1:264366520949:web:090c2f939c60626ed4163c",
  privacyUrl: "https://castilhanodev.github.io/astra-book/privacidade.html",
  contactEmail: "castilhanodev@gmail.com"
};
