# Textos para a ficha da Play Store

## Nome do app (até 30 caracteres)
Astra Book: Leitor de Livros

## Descrição curta (até 80 caracteres)
Leia PDF, EPUB e TXT com dicionário, marca-texto e frases para compartilhar.

## Descrição completa
Astra Book é um leitor de livros feito para quem ama ler no celular. Importe seus PDFs, EPUBs e TXTs e leia com uma experiência bonita, leve e cheia de recursos.

📖 LEITURA DO SEU JEITO
• Três tipos de virada de página: Simples (a mais leve), Médio (desliza) e 3D (dobra como papel)
• Temas Papel, Sépia, Cinza e Noite, e cada livro lembra o tema escolhido
• Zoom com trava: aproxime o PDF uma vez e todas as páginas abrem no mesmo tamanho
• Tela cheia: um toque no meio esconde tudo e deixa só você e o texto

🔎 DICIONÁRIO DENTRO DO APP
• Segure qualquer palavra para ver o significado em palavras simples
• Sinônimos que encaixam na frase: no plural, no feminino e no mesmo tempo do verbo
• Funciona sem internet
• Toda palavra procurada vai para o Meu dicionário, com modo Revisar para decorar

🖍️ MARCA-TEXTO E FRASES SALVAS
• Marque trechos em cinco cores, com notas
• Suas frases ficam em Frases salvas, com o nome do livro e do autor
• Compartilhe uma frase como imagem bonita no Story do Instagram

🔥 MOTIVAÇÃO
• Meta diária de leitura e sequência de dias seguidos
• 20 conquistas para desbloquear
• Cartão de sequência para postar no Instagram

📚 ORGANIZAÇÃO
• Estante com capas, progresso e busca
• Playlists de livros por gênero
• Agrupe por autor ou por série
• Edite título, autor e capa

☁️ SUA CONTA
• Crie uma conta para guardar destaques, frases, palavras, sequência e conquistas na nuvem e continuar em outro celular
• Ou use sem conta, só no aparelho
• Backup em arquivo para levar tudo com você

Os arquivos dos seus livros nunca saem do seu aparelho. Sem anúncios.

Dicionário: Dicionário Aberto (CC BY-SA), tesauros do LibreOffice, OpenThesaurus.PT e Onto.PT.

## Categoria
Livros e referências

## Tags sugeridas
Leitor de ebooks, Leitor de PDF, Livros, Dicionário, Estudo

## E-mail de contato
(o e-mail que você criar para o app)

## Site
https://SEU-USUARIO.github.io/astra-book/

## Política de Privacidade (link)
https://SEU-USUARIO.github.io/astra-book/privacidade.html
