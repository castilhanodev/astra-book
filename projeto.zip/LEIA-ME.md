# Astra Book (projeto para a Play Store)

Comece pelo arquivo **GUIA-PLAY-STORE.md**.

- `www/` é o app. `android/` é o projeto Android (Capacitor 8, Android 16).
- O login só liga depois de preencher `firebase-config.js`. Enquanto estiver vazio, o app funciona sem conta.
- Para gerar o app: GitHub > Actions > "Gerar app Android".
