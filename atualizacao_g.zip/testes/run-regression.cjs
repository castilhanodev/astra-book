const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');

const root = fs.existsSync(path.join(__dirname, 'www')) ? __dirname : path.resolve(__dirname, '..');
const testPage = fs.existsSync(path.join(root, 'www', 'index-integration.html')) ? 'index-integration.html' : 'index-teste.html';
const types = { '.html': 'text/html', '.js': 'text/javascript', '.json': 'application/json', '.pdf': 'application/pdf', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  const pathname = decodeURIComponent(new URL(req.url, 'http://local').pathname);
  const file = path.resolve(root, '.' + pathname);
  if (!file.startsWith(root + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (error, data) => {
    if (error) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(data);
  });
});

(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ headless: true, executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe' });
  const results = [];
  try {
    for (const viewport of [{ width: 900, height: 900 }, { width: 390, height: 844 }]) {
      const context = await browser.newContext({ viewport, deviceScaleFactor: viewport.width < 500 ? 2 : 1, isMobile: viewport.width < 500, hasTouch: true });
      if (viewport.width < 500) await context.addInitScript(() => {
        Object.defineProperty(navigator, 'deviceMemory', { configurable: true, get: () => 4 });
        Object.defineProperty(navigator, 'hardwareConcurrency', { configurable: true, get: () => 4 });
      });
      const page = await context.newPage();
      await page.goto(`http://127.0.0.1:${server.address().port}/www/${testPage}`, { waitUntil: 'load' });
      await page.locator('#integration-run').click();
      await page.waitForFunction(() => /^(PASSOU|FALHA|ERRO)/.test(document.title), null, { timeout: 90000 });
      const data = JSON.parse(await page.locator('#integration-result').textContent());
      const mascot = await page.evaluate(() => {
        const image = document.querySelector('#rLoading .astro[data-pose="livro"] img');
        const tutorialCss = [...document.styleSheets].some(sheet => {
          try { return [...sheet.cssRules].some(rule => rule.cssText?.includes('.astro.talk')); } catch { return false; }
        });
        return { loadingImage: !!image && image.complete && image.naturalWidth > 0, tutorialCss };
      });
      const zoom = await page.evaluate(() => window.__astraTestZoom());
      const features = await page.evaluate(() => window.__astraTestFeatures());
      const passed = data.passed === 38 && !data.failed.length && data.checks.every(check => check.passed) && mascot.loadingImage && mascot.tutorialCss &&
        (!zoom.lowPower || zoom.pixels <= 8000000) && features.quizBefore && features.quizReaction && features.soundButton && features.toggled && features.restored && features.limit === 15;
      results.push({ viewport, passed, data, mascot, zoom, features });
      if (viewport.width === 390) {
        await page.evaluate(() => { document.querySelector('#rLoading').hidden = false; document.querySelector('#rLoadMsg').textContent = 'Preparando a próxima página…'; });
        await page.screenshot({ path: path.join(root, 'testes', 'loading-regression.png') });
      }
      await context.close();
    }
  } finally {
    await browser.close();
    await new Promise(resolve => server.close(resolve));
  }
  console.log(JSON.stringify(results, null, 2));
  if (results.some(result => !result.passed)) process.exitCode = 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
