# Astra Book: guia para publicar na Play Store

Tudo que dava para fazer sem as suas contas já está pronto nesta pasta. Aqui está só o que depende de você, na ordem.

Tempo total estimado: 1 a 2 horas de cliques + 14 dias de teste fechado + até 7 dias de análise do Google.

---

## Situação de hoje (versão 3.2)

Já está pronto e testado, sem nada faltando no código:

- App completo (leitor, dicionário, marca-texto, frases, conquistas, backup, playlists)
- Login com e-mail e senha, Continuar com o Google e opção de usar sem conta
- Banco de dados na nuvem (Firebase/Firestore), com as regras de segurança aplicadas
- Meta diária e lembrete por notificação
- Plano grátis com limites, tela de planos, 1 mês grátis e assinatura pela Play Store
- Anúncios programados, mas **desligados** (ligam depois, trocando um arquivo)
- Chave de assinatura criada e guardada nos segredos do GitHub
- Robô do GitHub gerando o `.aab` assinado a cada atualização
- Páginas de Política de Privacidade e Excluir conta no ar
- Ícone, imagem de destaque, 11 capturas e os textos da ficha

Falta só o que depende de você (é tudo nos passos abaixo):

1. Subir o `projeto.zip` novo no GitHub e esperar o robô ficar verde
2. Criar a conta da Play Console (US$ 25, uma vez) e verificar a identidade
3. Preencher a ficha da loja e enviar o `.aab`
4. Criar as 3 assinaturas na Play Console (Passo 6)
5. Teste fechado com 12 testadores por 14 dias
6. Pedir acesso à produção

Os anúncios ficam para depois da publicação, com calma (Passo 6).

---

## O que tem nesta pasta

| Pasta / arquivo | O que é |
|---|---|
| `www/` | O app (o mesmo do site), com dicionário, fontes e tudo funcionando sem internet |
| `android/` | Projeto Android oficial (Capacitor 8, Android 16 / API 36) |
| `firebase-config.js` | **O único arquivo que você vai editar** (dados do Firebase e seu e-mail) |
| `firestore.rules` | Regras de segurança do banco (cada pessoa só vê os próprios dados) |
| `hosting/public/` | Política de Privacidade e página "Excluir conta" |
| `.github/workflows/` | Robôs do GitHub que geram o app (.aab e .apk) e publicam as páginas |
| `store/` | Ícone 512, imagem de destaque, 11 capturas de tela e os textos da ficha |

A **chave de upload** (`astra-upload.jks`) e a **senha** vêm num arquivo separado. Guarde os dois num lugar seguro (Google Drive da conta nova, por exemplo). Sem eles você não consegue atualizar o app depois.

---

## Passo 1. Conta Google nova

Crie a conta Google só para o app (ex.: `astrabook.app@gmail.com`). Use ela em tudo abaixo: Firebase, GitHub e Play Console.

---

## Passo 2. Firebase (login e banco de dados, grátis)

1. Entre em **console.firebase.google.com** com a conta nova e clique em **Criar projeto**. Nome: `astra-book`. Pode desligar o Google Analytics.
2. Menu **Authentication** > **Vamos começar** > aba **Método de login** > **E-mail/senha** > ativar > Salvar.
3. Menu **Firestore Database** > **Criar banco de dados** > local **southamerica-east1 (São Paulo)** > **modo de produção** > Criar.
4. Ainda no Firestore, aba **Regras**: apague tudo, cole o conteúdo do arquivo `firestore.rules` e clique em **Publicar**.
5. Engrenagem (Configurações do projeto) > **Seus apps** > ícone **</>** (Web) > apelido `astra-web` > Registrar. Vai aparecer um bloco `firebaseConfig = { apiKey: ... }`.
6. Abra o arquivo `firebase-config.js` e troque `window.ASTRA_FIREBASE = null;` por:

```js
window.ASTRA_FIREBASE = {
  apiKey: "COLE AQUI",
  authDomain: "COLE AQUI",
  projectId: "COLE AQUI",
  storageBucket: "COLE AQUI",
  messagingSenderId: "COLE AQUI",
  appId: "COLE AQUI",
  privacyUrl: "https://SEU-USUARIO.github.io/astra-book/privacidade.html",
  contactEmail: "astrabook.app@gmail.com"
};
```

Não precisa ativar o plano pago (Blaze). O login e o Firestore funcionam no plano grátis.

### Botão "Continuar com o Google"

7. **Authentication** > **Método de login** > **Adicionar novo provedor** > **Google** > ativar > escolha o e-mail de suporte > Salvar.
8. Engrenagem > **Seus apps** > **Adicionar app** > ícone do **Android**:
   - Nome do pacote: `com.astrabook.app`
   - Certificado SHA-1: `8E:DA:94:00:7D:8A:2A:2D:46:E8:43:FA:10:92:59:2C:97:24:31:66` (é da sua chave de upload)
   - Registrar > **Baixar google-services.json**. Guarde esse arquivo; ele vai para o GitHub no Passo 3.
9. Depois que o app estiver na Play Console (Passo 4), pegue o SHA-1 da chave da Google em **Play Console > Teste e lançamento > Integridade do app > Assinatura de apps** e adicione também no Firebase (mesmo lugar do item 8, botão **Adicionar impressão digital**). Sem isso, o botão do Google não funciona no app baixado da Play Store.

Se você pular esta parte, o app funciona normalmente só com e-mail e senha.

---

## Passo 3. GitHub (gera o app sem precisar instalar nada)

1. Crie conta em **github.com** com o e-mail novo.
2. Botão **New repository** > nome `astra-book` > **Public** > Create. (Público é o que libera o GitHub Pages e os robôs de graça. A chave NÃO vai para lá.)
3. Clique em **uploading an existing file** e arraste **todo o conteúdo desta pasta** (menos a chave). Commit.
   - Se o site não deixar arrastar a pasta `.github`, crie os arquivos pelo botão **Add file > Create new file** com o nome `.github/workflows/build.yml` e cole o conteúdo. Faça o mesmo com `paginas.yml`.
4. **Settings** > **Secrets and variables** > **Actions** > **New repository secret**, crie dois:
   - `ASTRA_KEYSTORE_B64`: cole todo o texto do arquivo `astra-upload.jks.base64.txt`
   - `ASTRA_KEYSTORE_PASSWORD`: a senha do arquivo `SENHA-DA-CHAVE.txt`
   - `GOOGLE_SERVICES_JSON`: abra o `google-services.json` num bloco de notas e cole todo o conteúdo (é o que liga o botão do Google)
5. **Settings** > **Pages** > em Source escolha **GitHub Actions**.
6. Aba **Actions** > rode **Publicar páginas** e depois **Gerar app Android** (botão *Run workflow*).
7. Quando o "Gerar app Android" ficar verde (uns 5 a 10 min), clique nele e baixe **astra-book-play-store**. Dentro tem:
   - `app-release.aab`: o arquivo para a Play Store
   - `app-release.apk`: para instalar e testar no seu celular
8. No Firebase: **Authentication** > **Configurações** > **Domínios autorizados** > adicione `SEU-USUARIO.github.io` (para a página de excluir conta funcionar).

Suas páginas ficam em:
- `https://SEU-USUARIO.github.io/astra-book/privacidade.html`
- `https://SEU-USUARIO.github.io/astra-book/excluir-conta.html`

---

## Passo 4. Play Console

1. Entre em **play.google.com/console** > criar conta **Pessoal** > pagar a taxa única (US$ 25) > verificar identidade (documento) e o celular (pelo app Play Console).
2. **Criar app**: nome `Astra Book`, idioma Português (Brasil), App, Gratuito.
3. Painel > **Configurar o app**. Responda assim:

| Item | Resposta |
|---|---|
| Política de Privacidade | link `.../privacidade.html` |
| Acesso ao app | "Algumas funcionalidades são restritas". Crie uma conta de teste no app (ex.: `teste.astrabook@gmail.com` / senha) e informe aqui |
| Anúncios | Não, o app não contém anúncios (enquanto o `ads-config.js` estiver com `null`; quando ligar o AdMob, volte aqui e mude para Sim) |
| Classificação do conteúdo | Categoria "Todos os outros tipos de app". Responda **Não** para violência, sexo, linguagem, drogas, apostas. Usuários interagem entre si? **Não**. Compartilha localização? **Não** |
| Público-alvo | 13 a 15, 16 a 17 e 18+ (não marque menores de 13) |
| Apps de notícias | Não |
| Apps governamentais / financeiros / saúde | Não |
| Segurança dos dados | veja a tabela abaixo |
| Exclusão de conta | link `.../excluir-conta.html` |
| Compras no app | Sim (assinatura Astra Pro, mensal, trimestral e anual) |
| Notificações | Nada a responder aqui; os lembretes são agendados no próprio celular (veja o Passo 7) |

### Segurança dos dados (Data safety)

- O app coleta ou compartilha dados? **Sim**
- Os dados são criptografados em trânsito? **Sim**
- O usuário pode pedir a exclusão? **Sim** (link da página de excluir conta)
- Compartilhamento com terceiros: **Nenhum** (o Firebase é prestador de serviço, não conta como compartilhamento)

| Tipo de dado | Coletado | Obrigatório? | Finalidade |
|---|---|---|---|
| Informações pessoais > Nome | Sim | Opcional | Funcionalidade do app, Gerenciamento da conta |
| Informações pessoais > Endereço de e-mail | Sim | Opcional | Gerenciamento da conta |
| Informações pessoais > IDs de usuário | Sim | Opcional | Gerenciamento da conta |
| Informações pessoais > Outras informações (opção de perfil e cor do tema) | Sim | Opcional | Funcionalidade do app |
| Atividade no app > Outros conteúdos gerados pelo usuário (destaques, notas, palavras) | Sim | Opcional | Funcionalidade do app |
| Atividade no app > Outras ações (progresso, sequência, conquistas) | Sim | Opcional | Funcionalidade do app |

"Opcional" porque o app funciona sem conta. Arquivos dos livros **não** são coletados (ficam só no aparelho).

4. **Ficha da loja principal**: use os textos de `store/textos-da-ficha.md`, o ícone `store/icone-512.png`, a imagem `store/imagem-destaque-1024x500.png` e as capturas de `store/capturas/` (pode subir até 8; as melhores são 01, 03, 05, 07, 08, 09, 10 e 11).
5. **Teste > Teste fechado** > criar faixa > **Criar versão** > aceite a **Assinatura de apps do Google Play** > envie o `app-release.aab`.
6. **Testadores**: crie uma lista de e-mails com **pelo menos 12 pessoas** (família, amigos, colegas da faculdade). Mande para elas o link de participação. Elas precisam aceitar e **instalar**, e ficar no teste por **14 dias seguidos** sem sair.
7. Depois dos 14 dias: Painel > **Solicitar acesso à produção** e responda as perguntas (como foi o teste, o que mudou). A análise leva até 7 dias.

Dica: peça para 14 ou 15 pessoas, para sobrar caso alguém saia.

---

## Passo 5. Atualizar o app depois

1. Abra `android/app/build.gradle` no GitHub e aumente `versionCode` (11 > 12 > 13...) e o `versionName` ("3.0" > "3.1").
2. O robô gera um novo `.aab` sozinho. Envie na Play Console, na mesma faixa.

---

## Importante: quem usa o APK antigo (2.x)

O app da Play Store tem outra assinatura, então o Android não deixa instalar por cima do APK antigo.

1. No app antigo: Perfil > Backup > **Fazer backup** (salve o arquivo).
2. Desinstale o app antigo e instale o da Play Store.
3. No app novo: Perfil > Backup > **Restaurar backup**.

---

## Se algo der errado

- **O robô "Gerar app Android" ficou vermelho:** abra o passo que falhou, copie o erro e me mande.
- **O login não funciona no app:** confira se o `firebase-config.js` foi colado certo (vírgulas e aspas) e se o E-mail/senha está ativado no Firebase.
- **A página de excluir conta dá erro:** confira o domínio autorizado no Firebase (Passo 3, item 8).

---

## Passo 6. Assinatura (Astra Pro) e anúncios

### 6.1 Criar os planos na Play Console

Monetização > **Produtos** > **Assinaturas** > **Criar assinatura**. Crie três, com estes IDs exatos (o app procura por eles):

| ID do produto | Nome | Plano base | Preço |
|---|---|---|---|
| `astra_pro_mensal` | Astra Pro mensal | mensal, renovação automática | R$ 8,90 |
| `astra_pro_trimestral` | Astra Pro trimestral | 3 meses, renovação automática | R$ 22,90 |
| `astra_pro_anual` | Astra Pro anual | anual, renovação automática | R$ 69,90 |

Em cada plano base, crie uma **oferta** com **período sem custo financeiro de 1 mês** (free trial). O cartão fica cadastrado na conta Google da pessoa e a cobrança começa sozinha se ela não cancelar.

Depois é só **ativar** cada assinatura. Enquanto o app não estiver publicado em alguma faixa (nem que seja o teste fechado), os preços não aparecem no app.

### 6.2 Testar a compra sem gastar

Play Console > **Configurações** > **Teste de licença**: coloque o e-mail dos testadores. Eles compram com cartão de teste, sem cobrança de verdade.

### 6.3 Anúncios (AdMob), quando você quiser ligar

1. Crie a conta em **admob.google.com** com a mesma conta Google.
2. Adicione o app (Android, `com.astrabook.app`) e crie dois blocos: um **intersticial** e um **vídeo premiado**.
3. No arquivo `ads-config.js` do projeto, troque `null` por:

```js
window.ASTRA_ADS = {
  interstitial: "ca-app-pub-SEU-ID/SEU-BLOCO",
  rewarded:     "ca-app-pub-SEU-ID/SEU-BLOCO",
  test: false
};
```

4. No `android/app/src/main/AndroidManifest.xml`, dentro de `<application>`, acrescente:

```xml
<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY"/>
```

5. Na Play Console, marque que o app **contém anúncios** e atualize a Segurança dos dados.

Enquanto o `ads-config.js` estiver com `null`, o app não mostra anúncio nenhum e nada quebra.

## Passo 7. Lembretes de leitura (notificações)

Já está tudo pronto no projeto, você não precisa configurar nada. Só é bom saber o que responder na Play Console:

- Quando a pessoa entra no app pela primeira vez, aparece a tela **"Quantos minutos por dia?"**. Ela escolhe a meta (5, 10, 20, 30 ou 60 minutos), liga o lembrete e escolhe o horário.
- Depois disso, dá para mudar em **Perfil → Meta diária e lembrete**.
- O app manda no máximo **duas notificações por dia**: a do horário escolhido e, se a meta do dia ainda não foi batida, uma às 21h30. Se a pessoa já leu o que combinou, a segunda é cancelada sozinha.
- O Android pede a permissão de notificação na hora em que a pessoa liga o lembrete (não na abertura do app), que é o jeito recomendado pelo Google.
- O app **não** usa alarme exato (`SCHEDULE_EXACT_ALARM` foi removido do manifesto de propósito), então não cai na política de permissões restritas da Play Store.
- Na ficha da Play Console, em **Segurança dos dados**, os lembretes não coletam nem enviam nada: tudo é agendado no próprio celular.
