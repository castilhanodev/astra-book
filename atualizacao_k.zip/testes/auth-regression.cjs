const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');

const root = path.resolve(__dirname, '..');
const mock = `window.ASTRA_FIREBASE={apiKey:'test',privacyUrl:'#'};
window.FB={
 initializeApp:()=>({}),initAuth:()=>({}),initDb:()=>({}),
 onAuthStateChanged:(_auth,cb)=>cb(location.search.includes('restore')?{uid:'login-test',email:'teste@example.com',displayName:'Teste'}:null),
 signInWithEmailAndPassword:async()=>({user:{uid:'login-test',email:'teste@example.com',displayName:'Teste'}}),
 createUserWithEmailAndPassword:async()=>({user:{uid:'signup-test',email:'nova@example.com',displayName:''}}),
 updateProfile:async()=>{throw Error('metadata unavailable')},
 sendEmailVerification:async()=>{throw Error('email unavailable')},
 doc:()=>({}),collection:()=>({}),
 getDoc:async()=>({exists:()=>false}),getDocs:async()=>({docs:[]}),
 setDoc:async()=>{throw Error('firestore unavailable')}
};`;
const server = http.createServer((req, res) => {
  const pathname = decodeURIComponent(new URL(req.url, 'http://local').pathname);
  if (pathname.endsWith('/firebase-config.js')) { res.setHeader('Content-Type', 'text/javascript'); return res.end(mock); }
  if (pathname.endsWith('/firebase.js')) { res.setHeader('Content-Type', 'text/javascript'); return res.end(''); }
  const file = path.resolve(root, '.' + pathname);
  if (!file.startsWith(root + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (error, data) => {
    if (error) { res.writeHead(404); return res.end(); }
    res.setHeader('Content-Type', path.extname(file)==='.html'?'text/html':'application/octet-stream');
    res.end(data);
  });
});

(async()=>{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const browser=await chromium.launch({headless:true,executablePath:'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'});
  try{
    const page=await browser.newPage();
    page.on('pageerror',error=>console.error('pageerror',error.message));
    await page.goto(`http://127.0.0.1:${server.address().port}/www/index.html`,{waitUntil:'load'});
    await page.locator('#lgMail').fill('teste@example.com');
    await page.locator('#lgPw').fill('secret1');
    await page.locator('#lgGo').click();
    await page.waitForFunction(()=>document.querySelector('#lib')&&!document.querySelector('#lib').hidden,null,{timeout:10000});
    console.log('PASSOU: login abre a estante mesmo sem novo evento de sessão.');
    const signup=await browser.newPage();
    await signup.goto(`http://127.0.0.1:${server.address().port}/www/index.html`,{waitUntil:'load'});
    await signup.locator('#lgTab [data-m="up"]').click();
    await signup.locator('#lgName').fill('Nova leitora');
    await signup.locator('#lgG button').first().click();
    await signup.locator('#lgMail').fill('nova@example.com');
    await signup.locator('#lgPw').fill('secret1');
    await signup.locator('#lgPw2').fill('secret1');
    await signup.locator('#lgOk').check();
    await signup.locator('#lgGo').click();
    await signup.waitForFunction(()=>document.querySelector('#lib')&&!document.querySelector('#lib').hidden,null,{timeout:10000});
    console.log('PASSOU: cadastro abre a estante mesmo se os metadados não sincronizarem.');
    const restored=await browser.newPage();
    await restored.goto(`http://127.0.0.1:${server.address().port}/www/index.html?restore`,{waitUntil:'load'});
    await restored.locator('#auth .picker').waitFor({timeout:10000});
    console.log('PASSOU: sessão restaurada abre a seleção de perfil.');
  }finally{
    await browser.close();
    await new Promise(resolve=>server.close(resolve));
  }
})().catch(error=>{console.error(error);process.exitCode=1});
