const fs = require('node:fs');
const vm = require('node:vm');

const html = fs.readFileSync('www/index.html', 'utf8');
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)]
  .map(match => match[1])
  .filter(code => code.trim());

for (let index = 0; index < scripts.length; index++) {
  new vm.Script(scripts[index], { filename: `inline-${index + 1}.js` });
}

console.log(`Sintaxe aprovada em ${scripts.length} scripts inline.`);
