/* AstraBook PDF selection, 4.8-test.
 * PDF.js 3.11.174: associate the fontChar actually painted by Canvas with its
 * Unicode glyph from the operator list. Never relabel boxes by word count or
 * distribute a text item's width equally among characters.
 * Unsupported/incomplete drawing modes retain the original PDF.js text layer.
 */
(function () {
  'use strict';
  const L = window.pdfjsLib;
  if (!L || window.__astraRemendo) return;
  const pages = new WeakMap(), canvases = new WeakMap(), contexts = new WeakMap();
  const clean = s => String(s || '').normalize('NFKC').replace(/\s/g, '');
  const bag = s => Array.from(clean(s)).sort().join('');
  function put(map, key, value) {
    if (!map.has(key)) map.set(key, value);
    else if (map.get(key) !== value) map.set(key, null);
  }
  async function prepare(page) {
    if (pages.has(page)) return pages.get(page);
    const ready = (async () => {
      const op = await page.getOperatorList();
      const byId = new Map(), all = new Map();
      let fontId = null;
      const stack = [];
      for (let i = 0; i < op.fnArray.length; i++) {
        const fn = op.fnArray[i], args = op.argsArray[i];
        if (fn === L.OPS.save) stack.push(fontId);
        else if (fn === L.OPS.restore) fontId = stack.pop() || null;
        else if (fn === L.OPS.setFont) fontId = args[0];
        else if (fn === L.OPS.setGState) {
          for (const v of args[0] || []) if (v[0] === 'Font') fontId = v[1][0];
        } else if (fn === L.OPS.showText && fontId) {
          if (!byId.has(fontId)) byId.set(fontId, new Map());
          for (const g of args[0] || []) {
            if (!g || typeof g !== 'object' || typeof g.fontChar !== 'string' || typeof g.unicode !== 'string') continue;
            put(byId.get(fontId), g.fontChar, g.unicode);
            put(all, g.fontChar, g.unicode);
          }
        }
      }
      const fonts = [];
      for (const [id, chars] of byId) {
        try { const f = page.commonObjs.get(id); if (f && f.loadedName) fonts.push({name: f.loadedName, chars}); } catch (_) {}
      }
      return {fonts, all};
    })().catch(() => null);
    pages.set(page, ready);
    return ready;
  }
  function decode(meta, font, text) {
    if (!meta) return null;
    const exact = meta.fonts.find(f => font.includes(f.name));
    const chars = exact ? exact.chars : meta.all;
    if (chars.has(text)) return chars.get(text);
    let out = '';
    for (const c of text) {
      if (!chars.has(c) || chars.get(c) == null) return null;
      out += chars.get(c);
    }
    return out;
  }
  function record(ctx, text, x, y, maxWidth) {
    const state = contexts.get(ctx);
    if (!state || state.done) return;
    const unicode = decode(state.meta, ctx.font, String(text));
    if (unicode == null) { state.unknown++; return; }
    const m = ctx.getTransform(), metric = ctx.measureText(String(text));
    const sx = Math.hypot(m.a, m.b), sy = Math.hypot(m.c, m.d);
    const sizeMatch = /([\d.]+)px\b/.exec(ctx.font);
    const em = sizeMatch ? Number(sizeMatch[1]) : 0;
    if (!(sx > 0 && sy > 0 && em > 0)) return;
    const width = Math.min(metric.width, maxWidth > 0 ? maxWidth : Infinity) * sx;
    const ascent = Math.max(metric.actualBoundingBoxAscent || 0, em * .72) * sy;
    const descent = Math.max(metric.actualBoundingBoxDescent || 0, em * .18) * sy;
    const g = {text: unicode, x: m.a*x+m.c*y+m.e, y: m.b*x+m.d*y+m.f,
      ux: m.a/sx, uy: m.b/sx, vx: m.c/sy, vy: m.d/sy,
      width, ascent, descent, em: em*sy, space: ctx.measureText(' ').width*sx};
    // Fill-and-stroke draws the same glyph twice. Keep its Unicode only once.
    const previous = state.glyphs[state.glyphs.length-1];
    if (previous && previous.text===g.text && Math.hypot(previous.x-g.x,previous.y-g.y)<.01 && Math.abs(previous.width-g.width)<.01) return;
    state.glyphs.push(g);
  }
  function capture(ctx, meta) {
    if (!contexts.has(ctx)) {
      for (const method of ['fillText', 'strokeText']) {
        const original = ctx[method];
        ctx[method] = function (text, x, y, maxWidth) {
          try { record(this, text, x, y, maxWidth); } catch (_) {}
          return original.apply(this, arguments);
        };
      }
    }
    const state = {meta, glyphs: [], unknown: 0, done: false};
    contexts.set(ctx,state); canvases.set(ctx.canvas,state);
    return state;
  }
  function wordsFrom(glyphs) {
    const words = []; let word = null;
    for (const g of glyphs) {
      if (!g.text || /\s/.test(g.text)) { word = null; if (!g.text.trim()) continue; }
      // Multi-word fallback canvas strings cannot be positioned exactly.
      if (/\S\s+\S/.test(g.text)) return null;
      if (!g.text.trim()) continue;
      const dx = word ? g.x-word.x : 0, dy = word ? g.y-word.y : 0;
      const along = word ? dx*word.ux+dy*word.uy : 0;
      const across = word ? Math.abs(dx*word.vx+dy*word.vy) : 0;
      const gap = word ? along-word.width : 0;
      const same = word && Math.abs(g.ux-word.ux)<.015 && Math.abs(g.uy-word.uy)<.015 &&
        across < Math.max(1,Math.min(word.em,g.em)*.2) &&
        gap > -Math.min(word.em,g.em)*.25 && gap < Math.max(.6,Math.min(word.space,g.space)*.5);
      if (same) {
        word.text += g.text;
        word.width = Math.max(word.width,along+g.width);
        word.ascent = Math.max(word.ascent,g.ascent);
        word.descent = Math.max(word.descent,g.descent);
      } else { word = {...g}; words.push(word); }
    }
    return words;
  }
  /* O PDF pode desenhar palavras numa ordem interna diferente da ordem que a
     pessoa enxerga. Um Range do navegador segue a ordem interna e, ao arrastar
     por várias linhas, acaba selecionando palavras espalhadas pela página.
     Para páginas horizontais comuns, reorganiza os elementos invisíveis por
     linha (cima para baixo) e por posição (esquerda para direita). */
  function readingOrder(words) {
    const horizontal=words.filter(w=>Math.abs(w.uy)<.18&&w.ux>.7);
    if(horizontal.length<Math.max(2,words.length*.8))return words;
    const sorted=words.slice().sort((a,b)=>a.y-b.y||a.x-b.x), lines=[];
    for(const w of sorted){
      let best=null,dist=Infinity;
      for(const line of lines){const d=Math.abs(w.y-line.y);const tol=Math.max(2,Math.min(w.em,line.em)*.68);if(d<=tol&&d<dist){best=line;dist=d}}
      if(!best){best={y:w.y,em:w.em,items:[]};lines.push(best)}
      best.items.push(w);const n=best.items.length;best.y+=(w.y-best.y)/n;best.em=Math.max(best.em,w.em);
    }
    lines.sort((a,b)=>a.y-b.y);
    return lines.flatMap(line=>line.items.sort((a,b)=>a.x-b.x));
  }
  function canvasFor(tl) { return tl.parentElement && tl.parentElement.querySelector('canvas'); }
  function rebuild(tl) {
    if (!tl || !tl.isConnected) return false;
    const cv=canvasFor(tl), data=cv&&canvases.get(cv);
    if (!data || !data.done || data.unknown || !data.glyphs.length) return false;
    if (tl.__astraCanvas===cv && tl.__astraData===data) return true;
    // Avoid partial selections when glyphs were painted as paths or offscreen.
    if (bag(data.glyphs.map(g=>g.text).join(''))!==tl.__astraExpected) return false;
    let words=wordsFrom(data.glyphs); if (!words || !words.length) return false;
    words=readingOrder(words);
    const kx=(cv.offsetWidth||tl.offsetWidth)/cv.width;
    const ky=(cv.offsetHeight||tl.offsetHeight)/cv.height;
    if (!(kx>0&&ky>0)) return false;
    const fragment=document.createDocumentFragment(), boxes=[];
    let line=null, last=null;
    for (const w of words) {
      const h=w.ascent+w.descent;
      if (!(w.width>0 && h>0)) continue;
      if (!last || Math.abs((w.x-last.x)*last.vx+(w.y-last.y)*last.vy)>Math.max(w.em,last.em)*.5 || Math.abs(w.ux-last.ux)>.015 || Math.abs(w.uy-last.uy)>.015) {
        line=document.createElement('span'); line.style.cssText='position:absolute;left:0;top:0'; fragment.append(line);
      }
      const el=document.createElement('i');
      el.textContent=w.text+' ';
      const topX=w.x-w.vx*w.ascent, topY=w.y-w.vy*w.ascent;
      el.style.cssText='position:absolute;white-space:pre;transform-origin:0 0;font-style:normal;line-height:1;color:transparent;'+
        'left:'+(topX*kx)+'px;top:'+(topY*ky)+'px;width:'+w.width+'px;height:'+h+'px;font-size:'+h+'px;'+
        'transform:matrix('+(w.ux*kx)+','+(w.uy*ky)+','+(w.vx*kx)+','+(w.vy*ky)+',0,0)';
      // Match the invisible text's character distribution to its word box only.
      // The hit test below uses the PDF drawing geometry, never these DOM widths.
      line.append(el); boxes.push({el,w,topX,topY,h}); last=w;
    }
    if (!boxes.length) return false;
    tl.replaceChildren(fragment);
    // Text ranges and highlight rectangles must fit the same word boxes.
    for (const b of boxes) {
      const text=document.createElement('span'); text.textContent=b.el.textContent;
      text.style.cssText='position:static;display:inline-block;white-space:pre;transform-origin:0 0';
      b.el.replaceChildren(text);
      const natural=text.offsetWidth;
      if (natural>0) text.style.transform='scaleX('+(b.w.width/natural)+')';
      b.text=text;
    }
    tl.__astraBoxes=boxes; tl.__astraCanvas=cv; tl.__astraData=data;
    tl.style.transform=''; tl.dataset.astra='letras'; tl.dataset.astraMotivo='unicode-glyph';
    window.__astraRefeitas=(window.__astraRefeitas||0)+1;
    return true;
  }
  function layerAt(x,y) {
    const target=document.elementFromPoint(x,y), page=target&&target.closest('.pg');
    if (page) return page.querySelector('.textLayer');
    for (const tl of document.querySelectorAll('.textLayer')) {
      const cv=canvasFor(tl), r=cv&&cv.getBoundingClientRect();
      if (r&&x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom) return tl;
    }
    return null;
  }
  function targetAt(x,y,maxDistance=10) {
    const tl=layerAt(x,y); if (!tl) return null;
    rebuild(tl);
    const cv=canvasFor(tl); if (!cv || tl.__astraCanvas!==cv || tl.__astraData!==canvases.get(cv)) return null;
    const r=cv.getBoundingClientRect(), kx=r.width/cv.width, ky=r.height/cv.height;
    if (!(kx>0&&ky>0) || x<r.left||x>r.right||y<r.top||y>r.bottom) return null;
    const px=(x-r.left)/kx, py=(y-r.top)/ky;
    let best=null, distance=Infinity;
    for (const b of tl.__astraBoxes||[]) {
      const w=b.w, dx=px-b.topX, dy=py-b.topY;
      const det=w.ux*w.vy-w.uy*w.vx; if (Math.abs(det)<.01) continue;
      const lx=(dx*w.vy-dy*w.vx)/det, ly=(dy*w.ux-dx*w.uy)/det;
      const ax=Math.max(0,-lx,lx-w.width), ay=Math.max(0,-ly,ly-b.h);
      const score=Math.hypot(ax*kx,ay*ky*2);
      if (score<distance) {distance=score;best=b;}
    }
    // A blank margin must not select some distant word from the page.
    return best && distance<=maxDistance ? best.text : null;
  }
  function mappedAt(x,y) {
    const tl=layerAt(x,y); if (!tl) return false;
    rebuild(tl);
    const cv=canvasFor(tl);
    return !!(cv && tl.__astraCanvas===cv && tl.__astraData===canvases.get(cv));
  }
  function wrapPage(page,meta) {
    if (page.__astraUnicode) return page;
    page.__astraUnicode=true;
    const render=page.render.bind(page);
    page.render=function (options) {
      const ctx=options.canvasContext, state=ctx&&capture(ctx,meta);
      const task=render(options);
      task.promise.then(()=>{if(state)state.done=true;},()=>{});
      return task;
    };
    return page;
  }
  function wrapDoc(doc) {
    if (doc.__astraUnicode) return doc;
    doc.__astraUnicode=true;
    const get=doc.getPage.bind(doc);
    doc.getPage=number=>get(number).then(async page=>wrapPage(page,await prepare(page)));
    return doc;
  }
  function getDocument() {
    const task=L.getDocument.apply(L,arguments), promise=task.promise.then(wrapDoc);
    Object.defineProperty(task,'promise',{configurable:true,get:()=>promise});
    return task;
  }
  function renderTextLayer(options) {
    const task=L.renderTextLayer(options), tl=options.container;
    const items=options.textContentSource&&options.textContentSource.items;
    if (items) tl.__astraExpected=bag(items.map(it=>it.str||'').join(''));
    return {promise:task.promise.then(()=>{rebuild(tl);}),cancel:()=>task.cancel()};
  }
  window.pdfjsLib=new Proxy(L,{get:(target,key)=>key==='getDocument'?getDocument:key==='renderTextLayer'?renderTextLayer:Reflect.get(target,key,target)});
  window.__astraAlvo=targetAt;
  window.__astraAlvoProximo=(x,y)=>targetAt(x,y,70);
  window.__astraMapaAtivo=mappedAt;
  window.__astraRemendo='4.8-intervalo-visual';
  // Rebuild synchronously before a long press if hiRes replaced the canvas.
  document.addEventListener('pointerdown',event=>{const tl=layerAt(event.clientX,event.clientY);if(tl)rebuild(tl);},true);
})();
