package com.astrabook.app;

import android.content.ClipData;
import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;
import android.util.Base64;
import androidx.core.content.FileProvider;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileOutputStream;

// ponte entre o site e o Android: tela cheia e compartilhar arquivos
@CapacitorPlugin(name = "Astra")
public class AstraPlugin extends Plugin {

    private FileOutputStream out;
    private String fname;

    // abre a tela de notificacoes do proprio app (quando o usuario negou a permissao)
    @PluginMethod
    public void openNotificationSettings(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, getContext().getPackageName());
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception e) {
            try {
                Intent j = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getContext().getPackageName()));
                j.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(j);
            } catch (Exception e2) {
                call.reject("nao consegui abrir as configuracoes");
                return;
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void setImmersive(PluginCall call) {
        MainActivity.imm = Boolean.TRUE.equals(call.getBoolean("on", false));
        getActivity().runOnUiThread(() -> ((MainActivity) getActivity()).applyImm());
        call.resolve();
    }

    // começa um arquivo (imagem do story, backup)
    @PluginMethod
    public void fileBegin(PluginCall call) {
        try {
            File dir = new File(getContext().getCacheDir(), "share");
            dir.mkdirs();
            fname = call.getString("name", "arquivo").replaceAll("[^A-Za-z0-9._-]", "_");
            out = new FileOutputStream(new File(dir, fname));
            call.resolve();
        } catch (Exception e) {
            call.reject("erro ao criar arquivo");
        }
    }

    // recebe o arquivo em pedaços (base64)
    @PluginMethod
    public void fileAppend(PluginCall call) {
        try {
            out.write(Base64.decode(call.getString("data", ""), Base64.DEFAULT));
            call.resolve();
        } catch (Exception e) {
            call.reject("erro ao gravar");
        }
    }

    // abre a tela de compartilhar do Android (Instagram, WhatsApp, Drive...)
    @PluginMethod
    public void fileShare(PluginCall call) {
        try {
            out.close();
            File f = new File(new File(getContext().getCacheDir(), "share"), fname);
            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(call.getString("mime", "application/octet-stream"));
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.setClipData(ClipData.newRawUri("", uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, call.getString("title", "Compartilhar"));
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().runOnUiThread(() -> getActivity().startActivity(chooser));
            call.resolve();
        } catch (Exception e) {
            call.reject("erro ao compartilhar");
        }
    }
}
