# monta a pasta www (o site que vai dentro do app) a partir do astra.html
import os,re,shutil,glob
SRC='/home/claude/astra/astra.html';W='www'
shutil.rmtree(W,ignore_errors=True);os.makedirs(W+'/fonts')
s=open(SRC).read()
lines=s.split('\n');assert 'pdf.min.js' in lines[5] and 'jszip' in lines[8]
lines[5:9]=['<script src="pdf.min.js"></script>','<script src="jszip.min.js"></script>','<script src="firebase-config.js"></script>','<script src="ads-config.js"></script>','<script src="firebase.js"></script>']
s='\n'.join(lines)
s=re.sub(r'<link rel="preconnect"[^>]*>\n?','',s)
s=re.sub(r'<link rel="stylesheet" href="https://fonts.googleapis.com[^>]*>','<link rel="stylesheet" href="fonts/fonts.css">',s)
a="""workerSrc=(document.querySelector('script[src*="cdnjs"][src*="pdf.js"]')?'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js':'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/legacy/build/pdf.worker.min.js')"""
assert a in s;s=s.replace(a,"workerSrc='pdf.worker.min.js'")
s=re.sub(r'env\(safe-area-inset-(top|bottom|left|right),0px\)',r'var(--safe-area-inset-\1,env(safe-area-inset-\1,0px))',s)
back="""<script>
/* botão voltar do Android: fecha o que estiver aberto; se não tiver nada, sai do app */
(function(){var C=window.Capacitor;if(!C||!C.Plugins||!C.Plugins.App)return;
C.Plugins.App.addListener('backButton',function(){if(!(window.__astraBack&&window.__astraBack()))C.Plugins.App.exitApp()});})();
</script>"""
back=back+'\n<script src="patch.js"></script>'
s=s.replace('</body>',back+'\n</body>') if '</body>' in s else s+'\n'+back
if not s.lstrip().lower().startswith('<!doctype'):
    s='<!doctype html>\n<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,maximum-scale=1,user-scalable=no">\n'+s+'\n</html>'
open(W+'/index.html','w').write(s)
for f in ['pdf.min.js','pdf.worker.min.js','jszip.min.js']:shutil.copy('/home/claude/apk/assets/'+f,W)
shutil.copytree('/home/claude/astra/dict',W+'/dict')
shutil.copy('/home/claude/fontsrc/firebase.js',W)
if not os.path.exists('firebase-config.js'):
    open('firebase-config.js','w').write("""/* Configuração do Firebase do Astra Book.
   Enquanto estiver null, o app funciona só no aparelho (sem login).
   Para ligar o login: cole aqui os dados do seu app da Web no Firebase
   (Configurações do projeto > Seus apps > SDK do Firebase > Configuração). */
window.ASTRA_FIREBASE = null;
/* Exemplo de como fica depois de preenchido:
window.ASTRA_FIREBASE = {
  apiKey: "AIza...",
  authDomain: "astra-book-xxxx.firebaseapp.com",
  projectId: "astra-book-xxxx",
  storageBucket: "astra-book-xxxx.firebasestorage.app",
  messagingSenderId: "000000000000",
  appId: "1:000000000000:web:xxxxxxxx",
  privacyUrl: "https://astra-book-xxxx.web.app/privacidade.html"
};
*/
""")
shutil.copy('firebase-config.js',W)
if os.path.exists('ads-config.js'):shutil.copy('ads-config.js',W)
# arquivo de correcoes rapidas: roda depois do app, da para trocar so ele
if not os.path.exists('patch.js'):open('patch.js','w').write("/* correcoes rapidas do Astra Book: normalmente vazio */\n")
shutil.copy('patch.js',W)
# fontes locais (funcionam sem internet)
FS='/home/claude/fontsrc/node_modules/@fontsource/'
fam={'Unbounded':('unbounded',[(400,'normal'),(500,'normal'),(700,'normal')]),
 'Manrope':('manrope',[(400,'normal'),(500,'normal'),(600,'normal'),(700,'normal'),(800,'normal')]),
 'Literata':('literata',[(400,'normal'),(600,'normal'),(700,'normal'),(400,'italic')]),
 'JetBrains Mono':('jetbrains-mono',[(400,'normal'),(500,'normal'),(700,'normal')])}
css=''
for name,(pk,ws) in fam.items():
    for w,st in ws:
        fn=f'{pk}-latin-{w}-{st}.woff2';shutil.copy(FS+pk+'/files/'+fn,W+'/fonts/'+fn)
        css+=f"@font-face{{font-family:'{name}';font-style:{st};font-weight:{w};font-display:swap;src:url({fn}) format('woff2')}}\n"
open(W+'/fonts/fonts.css','w').write(css)
print('www ok',sum(os.path.getsize(p) for p in glob.glob(W+'/**',recursive=True) if os.path.isfile(p))//1024,'KB')
