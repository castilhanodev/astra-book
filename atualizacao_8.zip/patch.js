/* VERSAO DE TESTE: liga o diagnostico do toque.
   Mostra no alto da tela o que o app mediu quando voce segura numa palavra. */
window.__astraDebugSel = true;
