/* correcoes rapidas do Astra Book: normalmente vazio */
